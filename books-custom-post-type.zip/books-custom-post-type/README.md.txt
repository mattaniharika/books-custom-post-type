# Books Custom Post Type
A simple WordPress plugin that registers a custom post type "Books" and provides a shortcode [books_list].

## How to use
1. Install this plugin.
2. Go to **Books → Add New** to create book entries.
3. Use shortcode `[books_list]` on any page to display them.
