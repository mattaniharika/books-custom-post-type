<?php
/**
 * Plugin Name: Books Custom Post Type
 * Description: Registers a custom post type "Books" and displays them with a shortcode [books_list].
 * Version: 1.0
 * Author: Your Name
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) exit;

// Register custom post type
function bcp_register_books_cpt() {
    $labels = array(
        'name' => __( 'Books' ),
        'singular_name' => __( 'Book' )
    );
    $args = array(
        'label'               => __( 'Books' ),
        'public'              => true,
        'supports'            => array('title','editor','thumbnail'),
        'has_archive'         => true,
        'menu_icon'           => 'dashicons-book',
        'show_in_rest'        => true,
    );
    register_post_type( 'book', $args );
}
add_action( 'init', 'bcp_register_books_cpt' );

// Shortcode to list books
function bcp_books_list_shortcode() {
    $query = new WP_Query( array( 'post_type' => 'book', 'posts_per_page' => -1 ) );
    if ( $query->have_posts() ) {
        $output = '<ul>';
        while ( $query->have_posts() ) {
            $query->the_post();
            $output .= '<li><a href="' . get_permalink() . '">' . get_the_title() . '</a></li>';
        }
        $output .= '</ul>';
        wp_reset_postdata();
        return $output;
    } else {
        return '<p>No books found.</p>';
    }
}
add_shortcode( 'books_list', 'bcp_books_list_shortcode' );
